#ifndef STUDENT_HPP
#define STUDENT_HPP

#include <string>

const std::string student_name = "first_name last_name";
const int student_id = 0;

#endif // STUDENT_HPP
